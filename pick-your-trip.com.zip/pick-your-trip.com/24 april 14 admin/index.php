<script language="javascript">
window.location.href="login.php";
</script>